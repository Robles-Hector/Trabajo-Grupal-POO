package Grupo_K;
 
import java.util.Scanner; 

public class GrupoK_PersonaCensada {
	
	public Scanner scanner = new Scanner (System.in);
	public String nombre, apellido, genero, ocupacion, dni, etnia, fechaNacimiento;
	int edad;
	
	public GrupoK_PersonaCensada(){
		
	}
	
	public GrupoK_PersonaCensada (String nombre, String apellido, String genero, String ocupacion, String dni, String etnia, String fechaNacimiento, int edad){
		this.nombre = nombre;
		this.apellido = apellido;
		this.genero = genero;
		this.ocupacion = ocupacion;
		this.dni = dni;
		this.etnia = etnia;
		this.edad = edad;
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public void AgregarPersona(){
		
		System.out.println("Ingrese su nombre");
		nombre = scanner.nextLine();
		System.out.println("Ingrese su apellido");
		apellido = scanner.nextLine();
		System.out.println("Ingrese su genero");
		genero = scanner.nextLine();
		System.out.println("Ingrese su edad");
		edad = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese su fecha de nacimiento");
		fechaNacimiento = scanner.nextLine();
		System.out.println("Ingrese su ocupacion");
		ocupacion = scanner.nextLine();
		System.out.println("Ingrese su DNI");
		dni = scanner.nextLine();
		System.out.println("Ingrese su etnia");
		etnia = scanner.nextLine();
	}
	
	public void RegistrarPersona(){
		
		System.out.println("Nombre: " + nombre);
		System.out.println("Apellido: " + apellido);
		System.out.println("Genero: " + genero);
		System.out.println("Edad: " + edad);
		System.out.println("Fecha de nacimiento: " + fechaNacimiento);
		System.out.println("Ocupacion: " + ocupacion);
		System.out.println("DNI: " + dni);
		System.out.println("Etnia: " + etnia);
	}
	
}
