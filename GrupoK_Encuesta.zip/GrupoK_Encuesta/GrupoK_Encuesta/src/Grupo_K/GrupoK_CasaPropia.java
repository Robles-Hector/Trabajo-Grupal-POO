package Grupo_K;

public class GrupoK_CasaPropia extends GrupoK_Casa {
	//Atributos
	private int tiempoAdquisicion;
	private boolean cumplimientoImpuestos;
	private String hipoteca; 
	//Constructor
	public GrupoK_CasaPropia(String nombre, String apellido, int edad, String genero, String ocupacion, String DNI, String etnia, String fechaNacimiento, String direccion, int habitantes, int tiempoAdquisicion, boolean cumplimintoImpuestos, String hipoteca, boolean cumplimientoImpuestos) {
		super(nombre, apellido, edad, genero, ocupacion, DNI, etnia, fechaNacimiento, direccion, habitantes);
		this.tiempoAdquisicion = tiempoAdquisicion;
		this.cumplimientoImpuestos = cumplimientoImpuestos;
		this.hipoteca = hipoteca; 
	}
	//Metodos
    public void informacionHipoteca() {
        System.out.println("Información de la hipoteca: " + hipoteca);
    }
    //Getters y Setters
    public int getTiempoAdquisicion() {
        return tiempoAdquisicion;
    }

    public void setTiempoAdquisicion(int tiempoAdquisicion) {
        this.tiempoAdquisicion = tiempoAdquisicion;
    }

    public boolean isCumplimientoImpuestos() {
        return cumplimientoImpuestos;
    }

    public void setCumplimientoImpuestos(boolean cumplimientoImpuestos) {
        this.cumplimientoImpuestos = cumplimientoImpuestos;
    }

    public String getHipoteca() {
        return hipoteca;
    }

    public void setHipoteca(String hipoteca) {
        this.hipoteca = hipoteca;
    }
}
