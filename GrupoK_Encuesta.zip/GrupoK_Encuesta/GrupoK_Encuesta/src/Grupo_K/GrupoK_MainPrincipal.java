package Grupo_K;

import java.util.Scanner; 

public class GrupoK_MainPrincipal {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		GrupoK_Encuesta encuesta = new GrupoK_Encuesta();
		GrupoK_Barrio barrio =  new GrupoK_Barrio();
		//GrupoK_CasaPropia casaPropia =  new GrupoK_CasaPropia();
		int opcion, preguntaCasa;
		do
		{
			System.out.println("----------------------------");
			System.out.println("Ingrese la opcion a realizar");
			System.out.println("1. Iniciar encuesta");
			System.out.println("2. Salir");
			System.out.println("----------------------------");
			opcion = scanner.nextInt();	
			switch (opcion)
			{
			case 1:
				encuesta.AgregarPersona();
				encuesta.Encuesta();
				encuesta.RegistrarPersona();
				break;
			case 2:
				System.out.println("Gracias por utilizar este sistema de encuentas");
				break;
			default:
				System.out.println("La opcion ingresada de incorrecta");
			}
		}
		while (opcion != 2);
	}
}
