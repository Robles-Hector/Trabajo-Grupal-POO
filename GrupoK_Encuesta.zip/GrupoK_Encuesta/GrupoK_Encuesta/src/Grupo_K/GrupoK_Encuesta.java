package Grupo_K;

public class GrupoK_Encuesta extends GrupoK_PersonaCensada{
	private int idEncuesta, paredes, piso, habitaciones, banos, neveras, lavadoras, secadoras, televisores, vehiculos;
	public GrupoK_Encuesta() {
        // Constructor vacio
    }
	public GrupoK_Encuesta (String nombre, String apellido, String genero, String ocupacion, String dni, String etnia, String fechaNacimiento, int edad, int idEncuesta, int paredes, int piso, int habitaciones, int banos, int neveras, int lavadoras, int secadoras, int televisores, int vehiculos) 
	{
		super (nombre, apellido, genero, ocupacion, dni, etnia, fechaNacimiento, edad);
		this.idEncuesta = idEncuesta;
		this.paredes = paredes;
		this.piso = piso;
		this.habitaciones = habitaciones;
		this.banos = banos;
		this.neveras = neveras;
		this.lavadoras = lavadoras;
		this.secadoras = secadoras;
		this.televisores = televisores;
		this.vehiculos = vehiculos;
    }
	
	public void Encuesta()
	{
		System.out.println("Ingrese el materiasl de las paredes de la vivienda (1/5)");
		System.out.println("1. Hormigon/Bloque/Ladrillo");
		System.out.println("2. Madera");
		System.out.println("3. Caña/Estera");
		System.out.println("4. Adobe/Tapia");
		System.out.println("5. Otro");
		paredes = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese el materiasl del piso de la vivienda");
		System.out.println("1. Baldosa/Vinyl/Ceramica");
		System.out.println("2. Marmol/Marmeton");
		System.out.println("3. Cemento/Ladrillo");
		System.out.println("4. Tierra");
		System.out.println("5. Otro");
		piso = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de habitaciones");
		habitaciones = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de baños");
		banos = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de neveras");
		neveras = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de lavadoras");
		lavadoras = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de secadoras");
		secadoras = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de televisores");
		televisores = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Ingrese la cantidad de vehiculos");
		vehiculos = scanner.nextInt();
		scanner.nextLine();
	}
	
	@Override
	public void RegistrarPersona()
	{
		super.RegistrarPersona();
		System.out.println("Materiasl de las paredes: " + paredes);
		System.out.println("Materiasl del piso: " + piso);
		System.out.println("Cantidad de habitaciones: " + habitaciones);
		System.out.println("Cantidad de baños: " + banos);
		System.out.println("Cantidad de neveras: " + neveras);
		System.out.println("Cantidad de lavadoras: " + lavadoras);
		System.out.println("Cantidad de secadoras: " + secadoras);
		System.out.println("Cantidad de televisores: " + televisores);
		System.out.println("Cantidad de vehiculo: " + vehiculos);
	}
}
