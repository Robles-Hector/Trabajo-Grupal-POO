package Grupo_K;

import java.util.Scanner;

public class GrupoK_Barrio {
	//Atributo
    private String nombreBarrio; 
    private String tipoBarrio; 
    public  GrupoK_Barrio()
    {
    	
    }
    //Constructor
    public GrupoK_Barrio(String nombreBarrio, String tipoBarrio) {
    	this.nombreBarrio = nombreBarrio;
    	this.tipoBarrio = tipoBarrio; 
    }
    //Metodos
    public void ingresarDatosCasa(Scanner scanner) {
    	System.out.println("Ingrese el nombre del Barrio: ");
    	nombreBarrio=scanner.nextLine();
    	System.out.println("Ingrese el tipo de barrio: ");
    	tipoBarrio=scanner.nextLine();
    }
    public void mostrarDatosCasa() {
    	System.out.println("Barrio: " + nombreBarrio);
    	System.out.println("Tipo: " + tipoBarrio);
    }
    //Getters y Setters
    public String getnombreBarrio() {
    	return nombreBarrio;
    }
    public void setnombreBarrio(String nombreBarrio) {
    	this.nombreBarrio = nombreBarrio; 
    }
    public String gettipoBarrio() {
    	return tipoBarrio; 
    }
    public void settipoBarrio(String tipoBarrio) {
    	this.tipoBarrio = tipoBarrio;
    }
}
