package Grupo_K;

public class GrupoK_Casa {
	//Atrinutps
	private String direccion;
	private int habitantes; 
	//Constructor
	public GrupoK_Casa(String nombre, String apellido, int edad, String genero, String ocupacion, String DNI, String etnia, String fechaNacimiento, String direccion, int habitantes) {
		super();
		this.direccion = direccion;
		this.habitantes = habitantes; 
	}
	//Metodos
	public void registrarCasa() {
		System.out.println("Casa registrada en: " + direccion);
	}
	
	public void agregarHabitante() {
		this.habitantes++;
		System.out.println("Habitante agregado.");
		System.out.println("Total de habitantes: " + habitantes);
	}
	
	public void eliminarHabitante() {
		if(this.habitantes>0) {
			this.habitantes--;
			System.out.println("Habitante eliminado.");
			System.out.println("Total habitantes: " + habitantes);
		} else {
			System.out.println("No hay habitantes para eliminar.");
		}
	}
	//Getters y Setters
	public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getHabitantes() {
        return habitantes;
    }

    public void setHabitantes(int habitantes) {
        this.habitantes = habitantes;
    }
}
