package Grupo_K;

import java.util.Scanner; 

public class GrupoK_CasaArriendo extends GrupoK_Casa
{
	
	private int tiempoArriendo;
	private double valorArriendo;
	
	public GrupoK_CasaArriendo (String nombre, String apellido, int edad, String genero, String ocupacion, String DNI, String etnia, String fechaNacimiento, String direccion, int habitantes, int tiempoArriendo, double valorArriendo) {
		super(nombre, apellido, edad, genero, ocupacion, DNI, etnia, fechaNacimiento, direccion, habitantes);
		this.tiempoArriendo = tiempoArriendo;
		this.valorArriendo = valorArriendo;
    }
	public void IngresoCasaArriendo(){
		Scanner scanner = new Scanner(System.in); 
		System.out.println("Ingrese el tiempo que lleva arrendando");
		tiempoArriendo = scanner.nextInt();
		System.out.println("Ingrese el valor de l arriendo");
		valorArriendo = scanner.nextDouble();
	}
	@Override	
	public void agregarHabitante(){
		double valorTotal;
		valorTotal=tiempoArriendo*valorArriendo;
		System.out.println("Su gasto total en arriendo es: " + valorTotal);
	}
}
